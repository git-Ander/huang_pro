import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'documentation',
    templateUrl: './documentation.component.html'
})

export class DocumentationComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}